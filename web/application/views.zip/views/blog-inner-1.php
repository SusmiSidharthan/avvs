<!--<!doctype html>-->
<!--<html class="no-js" lang="en">-->

<!--<head>-->
<!--    <title>AVVVS - Blog</title>-->
<!--    <meta charset="utf-8">-->
<!--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />-->
<!--    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />-->
<!--    <meta name="author" content="">-->
<!--    <meta name="description" content="">-->

<!--    <meta name="keywords" content="">-->

<!--    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.png">-->

<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap" rel="stylesheet">-->
<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Roboto&display=swap" rel="stylesheet">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/avvvs.css">-->

<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/plugins.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/style.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/vendor.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">





<!--</head>-->

<?php include("web/assets/include/header-c.php");?> 

<!--<body id="blog-menu">-->



    <section class="banner-inner-classic">
        <img class="img-fluid about-banner-left-img" src="<?php echo base_url();?>assets/images/classical-banner-left.png">
        <div class="container">
            <h1>Authentic Kerala<br> Ayurveda Medicines
            </h1>
        </div>
        <img class="img-fluid banner-right-img" src="<?php echo base_url();?>assets/images/banner-right-img.png">
        <img class="img-fluid pot-banner" src="<?php echo base_url();?>assets/images/classic-pot.png">
    </section>

   

    <section class="producs-classic">
        <img class="img-fluid classic-tulasi" src="<?php echo base_url();?>assets/images/tulasi-small.png">
        <img class="img-fluid left-bg" src="<?php echo base_url();?>assets/images/classical-products-bg-left.png">
        <div class="container index-top">

            <!--<h1 class="m-5 text-center">MY BLOGS</h1>
  <hr>-->
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-detail light-bg">
                        <img src="<?php echo base_url();?>assets/images/blog/inner-pic/02.jpg" class="img-fluid blog-detail-pic">
                        <h3>Ayurvedic Answers
                        </h3>
                        <h5>R. Srinivasa Rangan</h5>
                        <h5><span>10</span> August 2020</h5>
                        <p>At this point, we know a bit about Ayurveda, but you might still have some questions like ‘Is it safe?’ ‘How does a medicinal practice with just plants and herbs work?’ This article answers some of those questions.<br><br>

                            Is Ayurveda safe and effective?<br><br>
                            Ayurveda is similar to any other medicinal practice. It works if and only the patient follows the conditions and dosages suggested by experts. It is completely safe under these conditions only. If not followed properly, it has a slight possibility of causing a side effect, like any other medical discipline. But this arises only in the case of human error. So I would say that the problem is with us, not Ayurveda.<br><br>

                            What are the three energies that are continuously referred to in Ayurveda?<br><br>
                            Ayurveda deals with three doshas or energies. Ayurveda considers the human body similar to the globe. The three energies- Vata, Pitta and Kapha, are associated with the five elements of nature- Water, Earth, Fire, Air, and Space. Vata is the energy associated with air and space, and talks about our blood flow and respiratory system. Pitta is the energy associated with fire. It talks about our digestive system. The final energy, Kapha associates with earth and water. Kapha focuses on the physical properties of our body that includes bones and muscles.
<br><br>
                            How does Ayurveda help in solving our problems?<br><br>
                            Ayurveda solves a problem, not by simply counteracting it, but by finding the root cause and dealing with it. Ayurveda is not the place for temporary remedies. It is all about treatment that lasts a lifetime. Did you know? Judging from your doshas, an expert can even deduce what problems you might get in the future.
<br><br>
                            Do you have to turn to a vegan diet if you are undergoing an ayurvedic treatment?<br><br>
                            No. Just because Ayurveda includes a lot of herbs and encourages a vegetarian diet at times, it does not mean that it is only meant for vegans or vegetarians. You can consume whatever you want, as long as you are not advised against it specifically by your doctor.
<br><br>
                            Does Ayurveda use only herbs?<br><br>
                            No. It majorly uses herbs due to their healing potential, but Ayurveda is not limited to just herbs. In fact, it even includes surgeries (Shalya-chikitsa), psychiatry (Bhutavidya), and pediatrics (Kaumarabhrutyam). Using these different parts of Ayurveda can help enrich your life as you know it.
<br><br>
                            Does Ayurveda tackle problems only based on your body, or does it also include changing your lifestyle?<br><br>
                            This is the most important part to know and understand in Ayurveda. Everything has a role. Everything has a part to play. Even the most minute details are included. This includes your diet, posture, surroundings, your place of accommodation, and even your favorite colour. Your doshas correspond to certain conditions. The more you are in sync with these conditions, the better will be your lifestyle. Ayurveda makes this a priority.
                        </p>
                    </div>

                </div>
                
                <div class="col-md-4">

                    <div class="row recent-box flex-container">
                        <div class="col-12">
                            <h4>Recent posts</h4>
                            <hr>
                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/001.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>21 July 2020</p>
                            <h6>Ancient Medicine, Contemporary Practices and Modern Technology, The Arya Vaidya Vilasini Vaidya Sala</h6>

                        </div>
                        <div class="col-12 border-line">

                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/002.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>10 August 2020</p>
                            <h6>Ayurvedic Answers</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/003.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>23 August 2020</p>
                            <h6>Stress : managing your headspace to de-stress</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/004.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>2 September 2020</p>
                            <h6>Ayurveda Vs Modern Medicine</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/recent-icon.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>14 September 2020</p>
                            <h6>Dinacharya: the ideal daily routine according to Ayurveda</h6>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </section>








 <?php include("web/assets/include/footernew.php");?>


    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>

    <!-- <script type="text/javascript" src="js/slider/vendor.JS"></script> -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/active.JS"></script>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/smoothscrolling.js"></script>








</body>

</html>