<!--<!doctype html>-->
<!--<html class="no-js" lang="en">-->

<!--<head>-->
<!--    <title>AVVVS - Blog</title>-->
<!--    <meta charset="utf-8">-->
<!--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />-->
<!--    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />-->
<!--    <meta name="author" content="">-->
<!--    <meta name="description" content="">-->

<!--    <meta name="keywords" content="">-->

<!--    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.png">-->

<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap" rel="stylesheet">-->
<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Roboto&display=swap" rel="stylesheet">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/avvvs.css">-->

<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/plugins.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/style.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/vendor.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">-->





<!--</head>-->


<?php include("web/assets/include/header-c.php");?> 


<!--<body id="blog-menu">-->


   

    <section class="banner-inner-classic">
        <img class="img-fluid about-banner-left-img" src="<?php echo base_url();?>assets/images/classical-banner-left.png">
        <div class="container">
            <h1>Authentic Kerala<br> Ayurveda Medicines
            </h1>
        </div>
        <img class="img-fluid banner-right-img" src="<?php echo base_url();?>assets/images/banner-right-img.png">
        <img class="img-fluid pot-banner" src="<?php echo base_url();?>assets/images/classic-pot.png">
    </section>

   
    <section class="producs-classic">
        <img class="img-fluid classic-tulasi" src="<?php echo base_url();?>assets/images/tulasi-small.png">
        <img class="img-fluid left-bg" src="<?php echo base_url();?>assets/images/classical-products-bg-left.png">
        <div class="container index-top">

            <!--<h1 class="m-5 text-center">MY BLOGS</h1>
  <hr>-->
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-detail light-bg">
                        <img src="<?php echo base_url();?>assets/images/blog/inner-pic/04.jpg" class="img-fluid blog-detail-pic">
                        <h3>Ayurveda Vs Modern Medicine
</h3>
                        <h5>Nalin Reddy</h5>
                        <h5><span>2</span> September 2020</h5>
                        <p>Ayurveda is not just a medicine, but it’s also a way of living. Ayurveda is an ancient science that originated around 5000 years ago. It’s, in fact, one of the world’s oldest health systems and has a proven beneficial effect on many health problems. It has helped many people achieve better physical and mental health and overcome some serious health problems. It’s a type of alternative medicine that is rooted in Hinduism and includes different procedures, Rasayana, body massages, aromatherapy and other healing methods. 
Ayurveda believes that the human body’s energy is ruled by constitutions that symbolize the energy of the Earth’s elements: vata which symbolizes air and space, pitta – water and fire, kapha –earth and water. These constitutions are also known as doshas and can be determined as life energies. A frail balance exists between these three doshas.<br>
When this balance is disrupted and one of the doshas is decreased or increased, our body becomes more vulnerable and can be attacked by different diseases. Every person has one dosha that is mainly expressed in their body, mood and even personal character features are also influenced by their dosha. Most people have the characteristics of two doshas.<br>
Ayurveda is based solely on natural therapeutic methods and one of the main purposes of Ayurveda is preventing diseases from appearing in our body. Ayurvedic medicine aims for disease prevention and fighting the symptoms of the development of a current disease. It follows the body’s natural cycles. Its healing therapies originate from India, while those of conventional medicine are influenced by the traditional medicines of China and other countries. <br>
Ayurveda mainly uses plant extracts in its herbal oils and medical products. The natural medicines used in Ayurveda are non-invasive and don’t contain any toxins. They can also be taken safely in combination with other medicines.<br>
Ayurveda therapies include the use of the healing properties of different kinds of plants like herbs, heavy metals (iron, lead, mercury, arsenic), minerals, specific gemstones, etc. The practice of using the medical properties of gemstones is called Rasa shastra in Ayurveda. Herbal Ayurveda medicines are given in the form of tablets, oils, powders, teas and extracts. Ayurveda uses the healing power of plants like aloe vera, turmeric, ginger, garlic both in its medical therapies and diet plan.<br>
Ayurveda medicine’s treatment methods are popularized beyond India’s borders and spread around the whole world. Modern medicine utilizes some of Ayurveda’s healing therapies for one main reason – they are effective. Western medicine has one pill for each disease, while Ayurveda looks at the Roga (disease) and the Rogi (patient) individually and provide a tailored treatment plan accordingly. The practitioner will identify your Dosha (Vata/Pitta/Kapha) and then prescribe your treatment. A vata type of headache is addressed differently than a Kapha prone headache. There is no one size fits all concept in Ayurveda.
Pros and cons come with both sciences. Western medicine practitioners are well trained to handle emergencies and with the evolution of high-quality biomedical technology, a plethora of treatments are available today. Ayurveda cannot be used alone during a casualty.<br>
The most notable difference between Ayurveda and modern medicine is that of the ‘safety’ of the former and the zero side effects! Modern medicine has earned a bad name because side effects are inevitable during any treatment. While a person undergoes treatment for one ailment, he is also developing another because body systems, particularly the liver and kidneys, suffer due to the chemical salts that are contained in the medicines. Side effects are developed due to the residues of modern medicines that remain in the body and interfere with the vital functions. Most of these residues start behaving as toxins and deteriorate the health down at the cellular level.<br>
When both the Western medicine practitioners and Ayurvedic practitioners work hand in hand, healthcare can tremendously be improved.

</p>
                    </div>

                </div>
                <div class="col-md-4">

                    <div class="row recent-box flex-container">
                        <div class="col-12">
                            <h4>Recent posts</h4>
                            <hr>
                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/001.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>21 July 2020</p>
                            <h6>Ancient Medicine, Contemporary Practices and Modern Technology, The Arya Vaidya Vilasini Vaidya Sala</h6>

                        </div>
                        <div class="col-12 border-line">

                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/002.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>10 August 2020</p>
                            <h6>Ayurvedic Answers</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/003.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>23 August 2020</p>
                            <h6>Stress : managing your headspace to de-stress</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/004.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>2 September 2020</p>
                            <h6>Ayurveda Vs Modern Medicine</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/recent-icon.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>14 September 2020</p>
                            <h6>Dinacharya: the ideal daily routine according to Ayurveda</h6>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </section>





 <?php include("web/assets/include/footernew.php");?>


    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
    //<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>

    <!-- <script type="text/javascript" src="js/slider/vendor.JS"></script> -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/active.JS"></script>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/smoothscrolling.js"></script>



</body>

</html>