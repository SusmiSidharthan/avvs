<!--<!doctype html>-->
<!--<html class="no-js" lang="en">-->

<!--<head>-->
<!--    <title>AVVVS - Blog</title>-->
<!--    <meta charset="utf-8">-->
<!--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />-->
<!--    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />-->
<!--    <meta name="author" content="">-->
<!--    <meta name="description" content="">-->

<!--    <meta name="keywords" content="">-->

<!--    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.png">-->

<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap" rel="stylesheet">-->
<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Roboto&display=swap" rel="stylesheet">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/avvvs.css">-->

<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/plugins.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/style.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/vendor.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">-->





<!--</head>-->


<?php include("web/assets/include/header-c.php");?> 


<!--<body id="blog-menu">-->



    <section class="banner-inner-classic">
        <img class="img-fluid about-banner-left-img" src="<?php echo base_url();?>assets/images/classical-banner-left.png">
        <div class="container">
            <h1>Authentic Kerala<br> Ayurveda Medicines
            </h1>
        </div>
        <img class="img-fluid banner-right-img" src="<?php echo base_url();?>assets/images/banner-right-img.png">
        <img class="img-fluid pot-banner" src="<?php echo base_url();?>assets/images/classic-pot.png">
    </section>



    <section class="producs-classic">
        <img class="img-fluid classic-tulasi" src="<?php echo base_url();?>assets/images/tulasi-small.png">
        <img class="img-fluid left-bg" src="<?php echo base_url();?>assets/images/classical-products-bg-left.png">
        <div class="container index-top">

            <!--<h1 class="m-5 text-center">MY BLOGS</h1>
  <hr>-->
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-detail light-bg">
                        <img src="<?php echo base_url();?>assets/images/blog/inner/4.png" class="img-fluid blog-detail-pic">
                        <h3>Dinacharya: the ideal daily routine according to Ayurveda
</h3>
                        <h5>Parimala Pratibha Konnur</h5>
                        <h5><span>14</span> September 2020</h5>
                        <p>Have you ever felt like you wanted to change something in your life? Maybe, maybe not. Perhaps you’ve occasionally felt the urge to get fitter or healthier or do something worthwhile to change your lifestyle. In the olden days, our ancestors lived life a little differently from what we do today, and overall it can be seen that they lived longer and healthier lives. According to Ayurveda, there is a particular way things should be done, based on our 3 pillar energies: Vata, Pitta and Kapha. This routine is called the Dinacharya.<br>

Wake up earlier(5:30-6 AM): “Early to bed, early to rise, makes a person healthy, wealthy and wise” is a saying that we’ve been hearing for ages. The pre-dawn hour is when your Vata is activated and your mind is highly receptive to information. This is why we tend to remember more details from dreams experienced early in the morning as opposed to those that occur at night. It is also scientifically proven that individuals that have an earlier bedtime tend to be less lethargic and more productive than the average individual.<br>

Oral hygiene: Along with brushing your teeth, you should also clean your tongue, preferably by using a scraper. This practice eliminates bad breath causing bacteria, draws toxins or ama out of the body, and prepares the digestive system by stimulating the taste buds. Oil pulling (Kavala graha) or the practice of swishing oil around the teeth can also help in improving oral hygiene. Massaging the gums is also a practice that helps in increasing circulation.<br>

Drink a glass of warm water: This practice energises your organs, helps in shedding toxins from the body and initiates the digestion process. The metabolic rate increases as well.<br>

Elimination: 1-3 bowel movements per day is healthy as it expels toxins from the body. Any less could cause a Vata imbalance leading to constipation.<br>

Neti and Nasya: Neti means “to guide” and Nasya means Nasal therapy. This practice involves using a neti pot to clear and moisturise the nasal pathway in order to keep it healthy and allow a balanced influx of air through. Nasya oils can be implemented too.<br>

Massaging the body: In Sanskrit, abhy means ‘to rub’ and anga means ‘limbs’ and together these terms define Ayurvedic massage. Taking some time to gently massage yourself using warm oil has several benefits including hydration and increased circulation. Placing a few drops of warm oil in your ear canals is also a good practice.<br>

Yoga, Pranayama and Meditation: When the sun comes out, your Kapha is activated, this is the time to be active and start moving around. Any form of exercise, based on your preferences and body type, can help in prolonging your energy through the day, but practicing yoga asanas can help in balancing your doshas and increase both physical and mental strength. Pranayama or breathwork helps in awakening the mind and cultivating energy. Prana is your breath, your ‘life force energy’ and ayam means ‘to control’. Including some meditation can also be beneficial in waking the mind up and staying mindful throughout the day.
<br>
Bathing: A bath with warm water is the best choice. You should wait at least half an hour after exercising to let the body cool down. Rather than using chemically produced soaps, that strip away the skin’s protectant sebum causing dehydration, Ayurveda recommends gently exfoliating the body with natural salts or sugars.
<br>
Food habits: It is ideally a good idea to eat three major meals throughout the day at around the same time each day. Chewing each bite properly and eating without any distractions improves digestion. A balanced breakfast is mandatory to begin the digestive process. Enjoying a cup of tea with your breakfast is advised as it moistens your food and helps in stoking your digestive fire or agni. A comparatively heavier meal is recommended for lunch as the Pitta is activated at this time. Dinner should be lighter and at least 2 hours before bedtime.
<br>
Recreation: In the evening it is recommended that you take out some time to either pursue a hobby or do something that you enjoy to unwind. The effectiveness of this increases if you add in time with family or social interaction in general.
<br>
Sleep(10 PM): 6 to 8 hours of sleep is beneficial to your body. During the hours of 10 PM-2 AM the body repairs and regenerates itself, so this is the best time to rest.
<br>
Change is the beginning of welcoming in miracles. In order to ensure that these practices push you towards your highest potential, try to implement them one by one, and introduce a new habit after the older one has stuck. Following these practices will ensure your overall well being and cultivate a practice of self-love. So, try some of these practices out and witness the beauty of Ayurveda!


</p>
                    </div>

                </div>
                <div class="col-md-4">

                    <div class="row recent-box flex-container">
                        <div class="col-12">
                            <h4>Recent posts</h4>
                            <hr>
                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/001.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>21 July 2020</p>
                            <h6>Ancient Medicine, Contemporary Practices and Modern Technology, The Arya Vaidya Vilasini Vaidya Sala</h6>

                        </div>
                        <div class="col-12 border-line">

                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/002.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>10 August 2020</p>
                            <h6>Ayurvedic Answers</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/003.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>23 August 2020</p>
                            <h6>Stress : managing your headspace to de-stress</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/004.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>2 September 2020</p>
                            <h6>Ayurveda Vs Modern Medicine</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/recent-icon.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>14 September 2020</p>
                            <h6>Dinacharya: the ideal daily routine according to Ayurveda</h6>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </section>









 <?php include("web/assets/include/footernew.php");?>




    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>

    <!-- <script type="text/javascript" src="js/slider/vendor.JS"></script> -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/active.JS"></script>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/smoothscrolling.js"></script>







</body>

</html>