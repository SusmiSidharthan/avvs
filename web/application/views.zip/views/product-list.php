

<!doctype html>
<html lang="en">
  <head>
      
      
      
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <?php if(count($meta> 0)) {?>
    
    	<title><?=$meta->meta_title?></title>
    	<meta name="description" content="<?=$meta->meta_descr?>">
    	<link rel="canonical" href="<?=$meta->canonical_link?>">
        <meta name="keywords" content="<?=$meta->meta_meta_key?>">
        <meta name="author" content="<?=$meta->	seo_name?>">
        
    <?php } ?>

   
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/fav.png">
    
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
    
    <!--- avv style --->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Roboto&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/avvvs.css">



    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/plugins.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/vendor.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">
    <!--- avv style end --->

  </head>
  <body id="home-menu">
      

      
      

 <!--- Header start--->
 <header class="head-a clearHeader clearfix">
     
        <nav id="global-nav" >


     <div class="pull-right d-flex align-items-center">
         <a href="#" id="overlay">

             <div class="humburger">
                 <!--<div class="burger"></div>-->
                 <div class="menu-icon btn1" data-menu="1">
                     <div class="icon-left"></div>
                     <div class="icon-right"></div>
                 </div>
             </div>

         </a>


         <div class="menu" style="display:none;">
             <img class="img-fluid" src="<?php echo base_url();?>assets/images/menu-bg.png">
             <ul>
                 <li>
                     <a class="active-home" href="<?= CUSTOM_BASE_URL;?>home">Home</a>
                     <a class="active-about" href="<?= CUSTOM_BASE_URL;?>about">About</a>

                    <a class="active-product show-hidden-menus" id="">Stores <i class="fa fa-caret-down" aria-hidden="true"></i></a>

                     <div class="hidden-menus" style="display:none;">
                         <ul>
                             <?foreach ($main_category as $cat) {
                             
                             $catmackratt = base64_encode($cat['cat_id'] .SALT_KEY.CKRAT_KEY);
                             ?>
                             <li><a href="<?= CUSTOM_BASE_URL.'product-list/'.$catmackratt;?>"><?=$cat['cat_name'] ;?></a></li>
                             <!--<li><a href="<?= CUSTOM_BASE_URL;?>classical-products">Classical</a></li>-->
                             <? } ?>
                         </ul>
                     </div>


                     <a class="active-ayurvaram" href="<?= CUSTOM_BASE_URL;?>ayurvaram">Ayurvaram</a>
                     <a class="active-gallery" href="<?= CUSTOM_BASE_URL;?>gallery">Gallery</a>
                      <a class="active-blog" href="<?= CUSTOM_BASE_URL;?>blog">Blog</a>
                     <!-- <a class="active-news" href="newsandevents.php">News & Events</a>-->
                     <a class="active-contact" href="<?= CUSTOM_BASE_URL;?>contact">Contact</a>
                     <a class="active-contact" href="<?= CUSTOM_BASE_URL;?>consulting">Book Your Appoinment</a>
                 </li>
             </ul>


         </div>
     </div>
 </nav>   
     
     
     
     
     
  <div class="">
   <div class="container-fluid">
       
     <div class="head-a-in clearfix">
         
      


     </div>
       
     
   
       
     <div class="">
      <div class="row">
          
<div class="col-md-12 col-lg-6 col-xl-6">
      <div class="menu-out12 bag-men-ab">

<!--      <nav class="applePie nav clearfix">
       <div class="menubtn"><i class="glyph-icon flaticon-menu-button"></i></div>
        <ul id="nav" class="clearfix">
          <?php foreach ($main_category as $key => $main_cat_row) { 
                
                $mainmackratt = base64_encode($main_cat_row['cat_id'] .SALT_KEY.CKRAT_KEY);
            ?>
           <li><a class ="outer" sectionId="<?= $main_cat_row['cat_id'] ?>" href="<?= CUSTOM_BASE_URL .'product-list/'.$mainmackratt; ?>"><?= $main_cat_row['cat_name']; ?></a>
              <ul id="<?= "output_".$main_cat_row['cat_id'] ?>">

              </ul>            
            </li>
             <?php } ?>
             
           
              <ul>
                <?php foreach ($list as $key => $cat_row) { 
                    
                    $offermackratt = base64_encode($cat_row->cat_id .SALT_KEY.CKRAT_KEY);
                
                ?>
                  <li><a href="<?= CUSTOM_BASE_URL . 'offers-category/'.$offermackratt; ?>"><?= $cat_row->cat_name; ?></a></li> 
                <?php  } ?>
               
              </ul>
            </li>



        </ul>
       </nav>-->
       
          <a href="<?= CUSTOM_BASE_URL;?>" class="hda-s-logo">
           <img src="<?php echo base_url();?>assets/images/logo.png" alt="avvvs">  
         </a>
         

     
     
               
      <div class="hda-nav clearfix">
      <nav class="applePie nav clearfix">
       <div class="menubtn"><i class="glyph-icon flaticon-menu-button"></i></div>
        <ul id="nav" class="clearfix">

             

             <!--<li><a href="#">Store</a>-->
             <!-- <ul>-->
             <!--      <li><a herf="#">test 2</a></li>-->
             <!--      <li><a herf="#">test 3</a></li>-->
             <!-- </ul> -->
             <li><a href="<?= CUSTOM_BASE_URL;?>product-list">Stores</a></li>
              <li><a href="<?= CUSTOM_BASE_URL;?>ayurvaram">Ayurvaram</a></li>
              <li><a href="<?= CUSTOM_BASE_URL;?>gallery">Gallery</a></li>

            </li>



        </ul>
       </nav>
     </div>   
         
         
         
       </div>
       </div>          
          
          

       
       
      <div class="col-md-12 col-lg-6 col-xl-6">
       <div class="he-le12">
           
        <div>
           
        <a href="<?= CUSTOM_BASE_URL;?>consulting" class="hda-s-appt">Book Your Appoinment</a>    
        
        <div class="hda-search">
            
          <button type="button" class="sea-fh12 dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="glyph-icon flaticon-magnifying-glass"></i>
          </button>
          <div class="dropdown-menu sea-drkj-12">
            <ul class="pro-tool-drop">  
             <li>
                 <form autocomplete="off" name="search" enctype="multipart/form-data" method="post" action="<?= CUSTOM_BASE_URL . 'product-list' ?>">
                   <input id="search" class="hd-sea" type="text" name="search" placeholder="Search for Products...">
                   <button class="hd-sub" type="submit"><i class="glyph-icon flaticon-magnifying-glass"></i></button> 
                 </form> 
                 <div id="key_display"></div>
             </li>

            </ul>    
          </div>  
            
        <?php if($search != ''){ ?>
        <input id="search_value" value="<?php echo $search; ?>"  type="hidden" name="search_value">  
        <? }else{ ?>
        <input id="search_value" value=""  type="hidden" name="search_value">  
        <? } ?>
            
          
        </div>
        
        
     
        
         <div class="hda-r clearfix">
         <div class="btn-group">

          <?php $session_data=$this->session->userdata('userDetails');?>

           <?php if(empty($session_data->id)) { ?>

         <button type="button" class="hda-ma" data-toggle="modal" data-target="#my-account"><i class="glyph-icon">
             <img src="<?php echo base_url();?>assets/images/login.svg" alt="">  
         </i></button>
         <?php } else{ ?>  
             
          <button type="button" class="log-pro dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?= $session_data->phone;?>
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <ul class="pro-tool-drop">  
             <li><a href="<?= CUSTOM_BASE_URL;?>my-profile">My Profile</a></li>
             <li><a href="<?= CUSTOM_BASE_URL. 'my-order' ?>">Order</a></li>
             <li><a href="<?= CUSTOM_BASE_URL. 'wish-list' ?>">Wish list</a></li>
             <li><a href="<?= CUSTOM_BASE_URL. 'user_login/logout' ?>">Logout</a></li>
            </ul>    
          </div>
           <?php } ?> 
         </div>  
         </div>

       
       
        <a class="hda-cart" href="<?= CUSTOM_BASE_URL;?>view-cart">
            <div class="hda-cart-ab"><img src="<?php echo base_url();?>assets/images/cart.svg" alt="avvvs"></div>
            <span><?= $cart_count;?></span>
        </a>
        
        
        <a class="hda-save" href="#">
            <img src="<?php echo base_url();?>assets/images/save.svg" alt="avvvs">
        </a>
        
        </div>
       </div>
       </div>


      </div>
     </div>
     
     
    </div>
   </div>
     



 </header>   
 <!--- Header end---> 

 
  <main role="main" class="filter-main">
    <div class="container-fluid">    
      <div class="row">
       <!-- Left side -->
        <div class="col-lg-3 col-xl-3">

<div class="flt-left-main clearfix">
  <a href="#flt-toggle-menu" id="flt-toggle"><span></span><h1>Category Filters</h1></a>
    <div id="flt-toggle-menu">
   
          <div class="flt-out-m">   
           <h1 class="flt-cate-txt had-non-s"><b>Filters</b></h1><hr>
              
      <ul id="accordion" class="flt-accordion">
		<li class="default open">
            <div class="link"><a>Category</a><i class="fa fa-arrow-down"></i></div>
			<ul class="submenu">
			     <?php foreach ($category as $key => $categorys) {  
				     
				     $catmackratt = base64_encode($categorys->cat_id .SALT_KEY.CKRAT_KEY);
        				 ?>
        				<li><a href="<?= CUSTOM_BASE_URL. 'product-list/'.$catmackratt; ?>"><?= $categorys->cat_name;?></a></li>
                <?php } ?>
         
			</ul>
		</li>

  <!--<li class="default open">
   	<div class="link"><a>Price</a><i class="glyph-icon flaticon-down-arrow fa-chevron-down"></i></div>   
    <ul class="submenu price-max14">
     <input type="hidden" id="hidden_minimum_price" value="<?php //echo $min_price; ?>" />
     <input type="hidden" id="hidden_maximum_price" value="<?php //echo $max_price; ?>" />
     <p id="price_show"><span class="price-s12"><b>QR:</b> <?php //echo $min_price; ?> </span> - <span class="price-s13"><b>QR:</b> <?php //echo $max_price; ?></span></p>
     <div id="price_range"></div>
    </ul>
  </li>-->
  
  	<li>
    	<div class="list-group">
        <?php foreach($feature as $features) { ?>
        <div class="link"><a><?= $features['name']; ?></a><i class="fa fa-arrow-down"></i></div>
			<ul class="submenu">
              <div class="">
                  <?php foreach($features['feature_var'] as $ftr_rows) { ?>
                  <div class="flt-check-out">
                      <label class="flt-con"> 
                        <input type="checkbox" class="common_selector feature" value="<?php echo $ftr_rows['f_var_id']; ?>" > 
                        <span class="checkmark"></span>
                      </label>
                      <span><?php echo $ftr_rows['variants_name']; ?></span>
                  </div>
                  <?php } ?>
                </div>
			</ul>
			</div>
			 <?php  } ?> 
		</li>
  
  
	<li class="default open">
        <?php foreach($option as $options) { ?>
        <div class="link"><a><?= $options['name']; ?></a><i class="fa fa-arrow-down"></i></div>
			<ul class="submenu">
              <div class="">
                  <?php foreach($options['option_var'] as $option_rows) { ?>
                  <div class="flt-check-out">
                      <label class="flt-con"> 
                        <input type="checkbox" class="common_selector option" value="<?php echo $option_rows['opt_var_id']; ?>" >
                        <span class="checkmark"></span>
                      </label>
                      <span><?php echo $option_rows['type_name']; ?></span>
                  </div>
                  <?php } ?>
                </div>
			</ul>
			 <?php  } ?> 
		</li>

		<li>
      <div class="link">Availability<i class="fa fa-arrow-down"></i></div>
			<ul class="submenu">
              <div class="">
                  <div class="flt-check-out">
                      <label class="flt-con"> 
                        <input type="checkbox" class="common_selector availability" value="1" >
                        <span class="checkmark"></span>
                      </label>
                      <span>Include Out of Stock</span>
                  </div>
                </div>
			</ul>
		</li>          
	</ul>  
 </div>       
</div>
  </div>
    </div>
            
        <div class="col-lg-9 col-xl-9">
          <div class="flt-right-main clearfix">
           <h2 class="fil-head-txt"><?php if(isset($cat_name)) { echo $cat_name;  } ?></h2>
              
            <!-- Nav tabs -->
          
            <div class="product-nav clearfix"> 
            
                <div class="filter-ty12">
                    <div class="prd-size-radio">
                       <input type="radio" class="common_selector pop" id="toggle-11" value="1" name="group1" checked="checked" >  
                       <label for="toggle-11">Popularity</label> 
                    </div>
                    <!--<div class="prd-size-radio">
                       <input type="radio" class="common_selector high" id="toggle-12" value="2" name="group1" >   
                       <label for="toggle-12">Low to High</label> 
                    </div>-->
                    <!--<div class="prd-size-radio">
                       <input type="radio" class="common_selector low" id="toggle-13" value="3" name="group1" >
                       <label for="toggle-13">High to Low</label> 
                    </div>-->
                    <div class="prd-size-radio">
                       <input type="radio" class="common_selector first" id="toggle-14" value="4" name="group1" >
                       <label for="toggle-14">Newest First</label>   
                    </div>
                </div> 
<!--            <ul class="nav nav-tabs" role="tablist">
              <li class="nav-item">
                <input type="radio" class="common_selector pop" value="1" name="group1" checked="checked" >Popularity
              </li>
              <li class="nav-item">
                <input type="radio" class="common_selector high" value="2" name="group1" >Low to High
              </li>
              <li class="nav-item">
                  <input type="radio" class="common_selector low" value="3" name="group1" >High to Low
              </li>
              <li class="nav-item">
                 <input type="radio" class="common_selector first" value="4" name="group1" >Newest First
              </li>
            </ul>-->
            <!-- /Nav tabs -->

        <!-- Tab panes -->
       
             <!--- box 1 --->
          
                <div class="filter_data">

                </div>
     
            
             
             <!--- /box 1 --->   
            
                  
      </div>  
    <!-- /Tab panes -->
  
     <div class="col-md-12">
      <div align="center" id="pagination_link" class="pro-pge16"></div>
     </div>
  
    
    
    </div> 
          
 </div>  
 
        </div>
       <!-- /Left side -->    
      </div>

 </main>    

<style>
#loading
{
 text-align:center; 
 background: url('<?php echo base_url(); ?>assets/loader.gif') no-repeat center;
 background-size:70px;
 height: 150px;
 padding-top:250px;
}
</style>







 <!-- My account model-->
<div class="modal fade bd-example-modal-lg" id="my-account" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content my-act-modal">
    <button type="button" class="close my-cart-close" data-dismiss="modal" aria-label="Close">
     <span class="glyph-icon flaticon-cancel"></span>
    </button>
      <div class="modal-body-my-act">
        <div class="my-act-lft">
          <div class="my-act-lft-a">  
            <h3>Log in</h3>
            <h4>Log in to use your AVVVS Account</h4>
          </div>
        </div>
        <div class="my-act-rgt">
         <div class="my-act-rgt-a">
          <div class="my-act-rgt-a-r">
           
           <h4>Mobile Number and Password to Log In</h4>
          </div>   
          <div class="my-act-rgt-a-l">
           <div class="my-act-qr">
              <input  name="mobile_number" id="mobile_number" type="text" class="form-control log-fi12" placeholder="Mobile number"/>
           <p style="color:orange;" class="help-block error-info" id="mobile_number_Err"></p>
           <input  name="password" id="password" type="password" class="form-control log-fi12" placeholder="Password"/> 
        
           <p style="color:orange;" class="help-block error-info" id="password_Err"></p>
           <div style="color:orange;" id="pass_msg"></div>
           <div style="color:orange;" id="not_exist"></div>
          <button id="password-login" type="submit"  class="btn btn-primary btn-block log13">Login</button>
          
           <div class="my-act-rgt-check">
            <input type="checkbox" id="myCheck"> <span>Keep me logged in</span>
           </div>
           </div> 
           <!--- <div class="my-act-or">Forgot</div> --->
           <a data-toggle="modal" data-target="#my-register" class="my-act-log-otp" href="#" data-dismiss="modal">New User ? SignUp</a>
          </div>

         </div> 
        </div>
      </div>
    </div>
  </div>
</div>
<!-- My account model--> 

 <!-- My Register model-->
<div class="modal fade bd-example-modal-lg" id="my-register" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content my-act-modal">
    <button type="button" class="close my-cart-close" data-dismiss="modal" aria-label="Close">
     <span class="glyph-icon flaticon-cancel"></span>
    </button>
      <div class="modal-body-my-act">
        <div class="my-act-lft my-act-lft2">
          <div class="my-act-lft-a">  
            <h3>Signup</h3>
            <h4>Signup to use your AVVVS account</h4>
          </div>
        </div>
        <div class="my-act-rgt">
         <div class="my-act-rgt-a">
          <div class="my-act-rgt-a-r">
           <h4>Phone Number and Password to Signup</h4>
          </div>
          <div class="my-act-rgt-a-l">
           <div class="my-act-qr">
              <input name="new_mobile_number" id="new_mobile_number" type="text" class="form-control log-fi12" placeholder="New Mobile Number"/>
           <p style="color:orange;" class="help-block error-info" id="newmobileErr"></p>
           <input  name="new_password" id="new_password" type="password" class="form-control log-fi12" placeholder="Set Password"/> 
           <p style="color:orange;" class="help-block error-info" id="newpasswordErr"></p>


          <div style="color:green;" id="sign_msg"></div>
          <div style="color:orange;" id="sign_msg_wrong"></div>

          <button id="new-password-login" type="submit"  class="btn btn-primary btn-block log13">SignUp</button>
           </div> 
          </div>

         </div> 
        </div>
      </div>
    </div>
  </div>
</div>
<!-- My account model--> 
      
      
      
   


   <!-- Footer -->
   
    <footer class="futer">
        <div class="container-fluid">
            <div class="col-md-12 col-lg-9 m-auto">
                <div class="row">
                    <div class="col-md-4">
                        <div class="social-area">
                            <ul class="d-flex align-items-center">
                                <li><img src="<?php echo base_url();?>assets/images/footer-logo.png"></li>
                                <li>|</li>
                                <a href="https://www.facebook.com/aryavaidyavilasini"><li><i class="fa fa-facebook-square" aria-hidden="true"></i></li></a>
                                <a href="https://www.instagram.com/avvvsglobal/?hl=en"><li><i class="fa fa-instagram" aria-hidden="true"></i></li></a>
                                <a href="https://www.twitter.com/avvvsglobal"><li><i class="fa fa-twitter-square" aria-hidden="true"></i></li></a>
                                <a href="https://www.youtube.com/channel/UCVAIUt6i46hT7eY1SZksJWQ"><li><i class="fa fa-youtube-square" aria-hidden="true"></i></li></a>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-8 align-items-center">
                        <div class="link-area">
                            <ul>
                                <li><a title="Contact" class="active-contact" href="<?= CUSTOM_BASE_URL;?>contact">Contact</a></li>
                              <!--  <li><a title="Shop" href="#">Shop</a></li>-->
                               <!-- <li><a title="News & Events"  class="active-news" href="newsandevents.php">News & Events</a></li>-->
                                <li><a title="Gallery" class="active-gallery" href="<?= CUSTOM_BASE_URL;?>gallery">Gallery</a></li>
                                <li><a title="Ayurvaram" class="active-ayurvaram" href="<?= CUSTOM_BASE_URL;?>ayurvaram">Ayurvaram</a></li>
                                <li><a title="Products" class="active-product" href="<?= CUSTOM_BASE_URL;?>product-list">Stores</a></li>
                                <li><a title="About" class="active-about" href="<?= CUSTOM_BASE_URL;?>about">About</a></li>
                                <li><a title="Home" class="active-home" href="<?= CUSTOM_BASE_URL;?>home">Home</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-line"></div>
            <p>© 2022 Aryavaidyavilasini. All Rights Reserved | Design & Technology <a href="http://www.akinoz.com/">Akinoz</a></p>
        </div>
    </footer>
    
    
    
    <script src="<?php echo base_url();?>assets/js/jquery-1.12.4.js"></script> 
        <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

        <script src="<?php echo base_url();?>assets/js/jquery-3.2.1.slim.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>

        <script src="<?php echo base_url();?>assets/js/custom.js"></script>
        <link href="<?php echo base_url();?>assets/css/jquery-ui.css" rel="stylesheet">
    
 <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>


    
        <script src="<?php echo base_url();?>assets/js/main.js"></script>
    
        <script src="<?php echo base_url();?>assets/js/script.js"></script>
    
        <script src="<?php echo base_url();?>assets/js/holder.min.js"></script>
    
        <script src="<?php echo base_url();?>assets/js/drop.js"></script>
    


<script type="text/javascript">

$( ".outer" ).mouseover(function() {

  var rowid = $(this).attr('sectionId');

   $.ajax({
        type: 'post',
        url: '<?= CUSTOM_BASE_URL . 'Main/get_sub_category' ?>', //Here you will fetch records 
        data: 'rowid=' + rowid, //Pass $id
        success: function (data) {

           $("#output_"+rowid).html(data);

        }
  });

});

</script>
         
 <script type="text/javascript">

  function fill(value) {

   $('#search').val(value);

   //Hiding "display" div in "search.php" file.
 
   $('#key_display').hide();

   if (value) {

    document.search.submit();

    }
 
}

   $(document).ready(function() {
  
       $("#search").keyup(function() {
      
           var name = $('#search').val();
    
           if (name == "") {
      
               $("#key_display").html("");
     
           }
      
           else {
      
               $.ajax({
      
                   type: "POST",
     
                   url: '<?= CUSTOM_BASE_URL;?>Main/list_item',
       
                   data: {
      
                       search: name
     
                   },
      
                   success: function(html) {
    
                       $("#key_display").html(html).show();
     
                   }
     
               });
     
           }
     
       });

   });

$(document).on('click', function (e) {
    
    if ($(e.target).closest("#key_display").length === 0) {
        $("#key_display").hide();
    }
    
});
</script>
      
<script>

    jQuery(".dropdown-item").click(function(e){
    //do something
    var location = $(this).attr('sectionId');
    
       $.ajax({
          
           type: "POST",
    
           url: '<?= CUSTOM_BASE_URL;?>Main/change_location',
    
           data: {
    
               location: location
    
           },
    
           success: function(html) {
    
            if(html=='1')
            {
    
              window.location.reload(html);
    
            }                 
    
           }
    
       });
    
    });

</script> 






<script>
$(document).ready(function(){

    filter_data(1);

    function filter_data(page)
    {
        $('html, body').animate({ scrollTop: 0 }, 0);
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var feature = get_filter('feature');
        var option = get_filter('option');
        var availability = get_filter('availability');
        var pop = get_filter('pop');
        var high = get_filter('high');
        var low = get_filter('low');
        var first = get_filter('first');
        var cat_id = <?php echo $cat_id ?>;
        var search = $('#search_value').val();


        $.ajax({
            url: '<?= CUSTOM_BASE_URL;?>Product_list/fetch_data/'+page,
            method:"POST",
            dataType:"JSON",
            data:{action:action, minimum_price:minimum_price, maximum_price:maximum_price, feature:feature, option:option,cat_id:cat_id,availability:availability, pop:pop, high:high, low:low, first:first,search:search},
            success:function(data)
            {

                $('.filter_data').html(data.product_list);
                $('#pagination_link').html(data.pagination_link);
                
                
            }
        })
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            filter.push($(this).val());
        });
        return filter;
    }

    $(document).on('click', '.pagination li a', function(event){
        event.preventDefault();
        var page = $(this).data('ci-pagination-page');
        filter_data(page);
    });

    $('.common_selector').click(function(){
        filter_data(1);
    });

    $('#price_range').slider({
        range:true,
        min:<?= $min_price; ?>,
        max:<?= $max_price; ?>,
        values:[<?= $min_price; ?>,<?= $max_price; ?>],
        step:1,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data(1);
        }

    });

});
</script>
<script>
$(function() {
    var header = $(".clearHeader");
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
    
        if (scroll >= 80) {
            header.removeClass('clearHeader').addClass("darkHeader");
        } else {
            header.removeClass("darkHeader").addClass('clearHeader');
        }
    });
});  
</script>

 <script>

  $(function () {

  $('#password-login').on('click', function (e) {

    var mobile_number = $('#mobile_number').val();

    var password = $('#password').val();

   if (mobile_number == ''  )
   {
      document.getElementById("mobile_number_Err").innerHTML = "The field is required"; 
      status=false; 
   }
   else {
      document.getElementById('mobile_number_Err').innerHTML = "";
   }

  if (password == ''  )
   {
      document.getElementById("password_Err").innerHTML = "The field is required"; 
      status=false; 
   }
   else {
      document.getElementById('password_Err').innerHTML = "";
   }
    e.preventDefault();

    $.ajax({
      type: 'post',
      url: '<?= CUSTOM_BASE_URL;?>User_login/login_password',
      data: 'mobile_number=' + mobile_number + '&password=' + password,

      success: function (data) {

        if(data==1) {

          location.reload();                 
        }

        else if(data==2) {

          document.getElementById("not_exist").innerHTML = 'No user Exist..please Sign Up';
   
        }

         else if(data==3) {

          document.getElementById("pass_msg").innerHTML = 'user name or password are incorrect';

        }

        else{

          document.getElementById("pass_msg").innerHTML = '';

        }          
      }

    });

  });

 });

 </script>

 <script>

 $(function () {

  $('#new-password-login').on('click', function (ee) {

    var phone = $('#new_mobile_number').val();

    var pass = $('#new_password').val();


   if (phone == ''  )
   {
      document.getElementById("newmobileErr").innerHTML = "The field is required"; 
      status=false; 
   }
   else {
      document.getElementById('newmobileErr').innerHTML = "";
   }

  if (pass == ''  )
   {
      document.getElementById("newpasswordErr").innerHTML = "The field is required"; 
      status=false; 
   }
   else {
      document.getElementById('newpasswordErr').innerHTML = "";
   }
    ee.preventDefault();

    $.ajax({
      type: 'post',
      url: '<?= CUSTOM_BASE_URL;?>User/index',
      data: 'phone=' + phone + '&pass=' + pass,

      success: function (data) {

        if(data==1) {

          document.getElementById("sign_msg").innerHTML = 'User Sucessfully Sign In';              
        }

        if(data==2) {

          document.getElementById("sign_msg_wrong").innerHTML = 'User Already Registered';              
        }

        else{

          document.getElementById("sign_msg_wrong").innerHTML = '';

        }          
      }

    });

  });

});

 </script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script>
    $(document).ready(function(){
      $("#hide").click(function(){
        $("p").hide();
      });
      $("#show").click(function(){
        $("p").show();
      });
    });
    </script> 
    










    
    



  
    

  </body>
</html>


 