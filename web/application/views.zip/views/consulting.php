<?php include("web/assets/include/header-c.php");?>




  <main role="main" class="consult-main">



<section class="gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Book your consultation</h3>
           <br>
           
           
           
        <form enctype="multipart/form-data" method="post" action="<?= CUSTOM_BASE_URL.'addconsulting' ?>">
          

              <div class="row">
                <div class="col-md-6 mb-4">
                    
                    
                  <div class="form-outline">
                    <span class="red-star">★</span> <label class="form-label" for="firstName">Patient First Name</label>
                    <input required type="text" name="firstname" class="form-control form-control-lg" />
                   
                  </div>


                </div>
                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <label class="form-label" for="lastName">Patient Last Name</label>
                    <input type="text" name="lastname" class="form-control form-control-lg" />
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center">

                  <div class="form-outline datepicker w-100">
                    <span class="red-star">★</span><label for="birthdayDate" class="form-label">Age</label>  
                    <input required
                      type="number"
                      min="1" step="0"
                      class="form-control form-control-lg"
                      name="age"
                    />
                  </div>

                </div>
                <div class="col-md-6 mb-4">
                 <div class="form-outline">
                 <h6 class="mb-2 pb-1"> <span class="red-star">★</span>Gender: </h6>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="gender"
                      id="femaleGender"
                      value="female"
                      checked
                    />
                    <label class="form-check-label" for="femaleGender">Female</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="gender"
                      id="maleGender"
                      value="male"
                    />
                    <label class="form-check-label" for="maleGender">Male</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="gender"
                      id="otherGender"
                      value="other"
                    />
                    <label class="form-check-label" for="otherGender">Other</label>
                  </div>
                  
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 pb-2">

                  <div class="form-outline">
                    <span class="red-star">★</span><label class="form-label" for="emailAddress">Place</label>  
                    <input required type="text"  name="place" class="form-control form-control-lg" />
                  </div>

                </div>
                <div class="col-md-6 mb-4 pb-2">

                  <div class="form-outline">
                    <span class="red-star">★</span><label class="form-label" for="phoneNumber">Date</label>
                    <input required type="date" name="date" class="form-control form-control-lg date-wr-sl12" />
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6">
                   <div class="form-outline"> 
                   
                   <div>
                     <span class="red-star">★</span> <label class="form-label">Choose your Time slot</label>
                   </div>
                   
                   <select name="timeslot" class="select form-control-lg time-ag-sl12" required>
                    <option  disabled>Choose Time slot</option>
                    <option value="7:00 Am - 11:00 Pm">7:00 Am - 11:00 Pm</option>
                    <option value="11:00 Am - 3:00 Pm"> 11:00 Am - 3:00 Pm</option>
                    <option value="3:00 Pm - 7:00 Pm">3:00 Pm - 7:00 Pm</option>
                    <option value="7:00 Pm - 10:00 Pm">7:00 Pm - 10:00 Pm</option>
                  </select>
                  </div>
                  
                </div>
              
              
              <div class="col-md-6">

                  <div class="form-outline datepicker w-100">
                    <span class="red-star">★</span><label for="phone" class="form-label">Phone Number</label>  
                    <input required
                      type="number"
                      min="10" step="0"
                      class="form-control form-control-lg"
                      name="phone"
                    />
                  </div>
                 </div> 
                 </div> 
                  
                  

              <div class="mt-4 pt-2">
                <input class="consul-dg-bt12" type="submit" value="Submit" />
              </div>

            </form>
            
            
            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

 
 </main> 



 <?php include("web/assets/include/footer.php");?>
