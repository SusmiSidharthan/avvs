<?php include("web/assets/include/header-c.php");?> 

    <div class="slider-area-wrapper fix">
        
        
        <div class="rev_slider_wrapper fullscreen-container" data-alias="classic-agency" data-source="gallery">
            <div id="rev_slider_25_1" class="rev_slider fullscreenbanner" data-version="5.4.7">
                <ul>
                    <!-- SLIDE  -->
                    <li data-index="rs-57" data-transition="parallaxhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="assets/img/rev-slider/home-landing/100x50_home_onepage_016.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                        <!-- MAIN IMAGE --> <img src="<?php echo base_url();?>assets/assets/img/rev-slider/home-landing/home_onepage_016.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina><!-- LAYERS -->
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-resizeme" id="assets/img/rev-slider/home-landing/img/rev-slider/home-landing/" data-x="['center','center','center','center']" data-hoffset="['-40','-11','0','3']" data-y="['middle','middle','middle','middle']" data-voffset="['-13','-82','-59','-95']" data-fontsize="['79','60','50','50']" data-lineheight="['100','80','50','50']" data-fontweight="['700','400','400','400']" data-color="['rgba(255,255,255,1)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-type="text" data-responsive_offset="on" data-frames='[{"delay":500,"speed":2500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"frame":"999","to":"y:bottom;","ease":"Power3.easeInOut"}]' data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[140,30,30,30]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[140,30,30,30]" style="z-index: 5;  white-space: nowrap; font-size: 79px; line-height: 92px; font-weight: 700; color: rgba(255,255,255,1);">100 years of Ayurveda <br>legacy and heritage
                             </div><!-- LAYER NR. 2 -->
                        <!-- LAYER NR. 3 -->

                    </li><!-- SLIDE  -->
                    <li data-index="rs-58" data-transition="parallaxhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="assets/img/rev-slider/home-landing/Banner2.png" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                        <!-- MAIN IMAGE --> <img src="<?php echo base_url();?>assets/assets/img/rev-slider/home-landing/Banner2.png" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina><!-- LAYERS -->
                        <!-- LAYER NR. 5 -->
                        <div class="tp-caption tp-resizeme" id="assets/img/rev-slider/home-landing/img/rev-slider/home-landing/" data-x="['center','center','center','center']" data-hoffset="['-40','-11','0','3']" data-y="['middle','middle','middle','middle']" data-voffset="['-13','-82','-59','-95']" data-fontsize="['79','60','50','50']" data-lineheight="['100','80','50','50']" data-fontweight="['700','400','400','400']" data-color="['rgba(255,255,255,1)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-type="text" data-responsive_offset="on" data-frames='[{"delay":500,"speed":2500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"frame":"999","to":"y:bottom;","ease":"Power3.easeInOut"}]' data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[140,30,30,30]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[140,30,30,30]" style="z-index: 5;  white-space: nowrap; font-size: 79px; line-height: 92px; font-weight: 700; color: rgba(255,255,255,1);">Timetested authentic <br>
                           Ayurveda formulations</div><!-- LAYER NR. 6 -->

                    </li><!-- SLIDE  -->
                    <!--<li data-index="rs-59" data-transition="parallaxhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="assets/img/rev-slider/home-landing/100x50_home_onepage_016.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">-->
                        <!-- MAIN IMAGE --> <img src="<?php echo base_url();?>assets/assets/img/rev-slider/home-landing/home_onepage_016.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina><!-- LAYERS -->
                        <!-- LAYER NR. 7 -->
                    <!--    <div class="tp-caption tp-resizeme" id="assets/img/rev-slider/home-landing/img/rev-slider/home-landing/" data-x="['center','center','center','center']" data-hoffset="['-40','-11','0','3']" data-y="['middle','middle','middle','middle']" data-voffset="['-13','-82','-59','-95']" data-fontsize="['79','60','50','50']" data-lineheight="['100','80','50','50']" data-fontweight="['700','400','400','400']" data-color="['rgba(255,255,255,1)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-type="text" data-responsive_offset="on" data-frames='[{"delay":500,"speed":2500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"frame":"999","to":"y:bottom;","ease":"Power3.easeInOut"}]' data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[140,30,30,30]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[140,30,30,30]" style="z-index: 5;  white-space: nowrap; font-size: 79px; line-height: 92px; font-weight: 700; color: rgba(255,255,255,1);">100 years of Ayurveda <br>legacy and heritage</div><!-- LAYER NR. 8 -->-->


                    <!--</li>-->
                </ul>
                <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
            </div>
        </div>
    </div>


    <section class="home-intro">
        
            <?php if($responce = $this->session->flashdata('appoinment_msg')): ?>
                
                 <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong><?php echo $responce;?>.</strong> 
                  </div>
            
            <?php endif;?>


    
        <div class="container">
            <div class="intro-inner">
             

                <h2>Fine Blend of Authentic Ayurveda <br>and Contemporary Technology</h2>


                <p>Arya Vaidya Vilasini Vaidya Sala was established in 1921 with the blessings of Sree Narayana Guru by Kaloor Neelakantan Vaidyar as a pharmacy preparing and dispensing Ayurveda medicines. The firm gained popularity and prospered into a manufacturing unit with retail agencies and a clinic for patient care under Ramdas Vaidyar a renowned physician and socio-literary figure known for his satire and positive sarcasm. Dr. Manoj Kaloor former professor of Shalakya Tantra and presently CCIM member succeeded his father and developed the manufacturing unit into a modern state of the art technologically advanced factory.</p>
                <p>The clinic diversified into Ayurvaram Specialty Clinics specialised in Women Health, Gynaecology, Prenatal-Postnatal Care, Beauty Therapy, Headaches, Lifestyle, and Child Health etc.  The factory caters to supply of AVVVS domestically and AVVVS exports the products to countries like Russia, Austria, Columbia and other countries. The new venture of AVVVS is the e-commerce segment.  </p>



                <a class="read-mre-line" href="<?= CUSTOM_BASE_URL;?>about"">Read More</a>
            </div>
        </div>
    </section>

    <section class="product-first">
     <!--   <h6>Blend of technology & <br>
            <span>100 years</span> of tradition</h6>-->
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="gel-box">
                        <div class="border-box">
                            <img class="img-fluid" src="<?php echo base_url();?>assets/images/gel-box-2.png">

                            <h4>Mezhu<br>
                            <span>Thailam</span></h4>
                            <p>The best of both worlds can be achieved if we blend together</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="row pr-right-area">
                        <div class="col-md-5">
                            <div class="bottle-image">
                                <img class="img-fluid" src="<?php echo base_url();?>assets/images/bottles.png">
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="botle-text">
                                <img class="img-fluid" src="<?php echo base_url();?>assets/images/tulasi.png">
                                <h3>Herbal Kerala Ayurveda Patent and Classical Formulations </h3>
                            </div>
                        </div>

                        <p>Arya Vaidya Vilasini Vaidya Sala has always produced quality medicines using the best natural ingredients. The product list includes many effective in-house formulae like Mezhu Thailam. The AVVVS range of products also includes an array of patented medicines which are highly recommended by clinicians worldwide for their efficacy. Rujanth, Slepan, Redirons and Lakshol are a few examples   </p>

                        <a class="read-mre-line" href="<?= CUSTOM_BASE_URL;?>product-list">Stores</a>
                    </div>


                </div>
            </div>

        </div>
    </section>


    <section class="pr-grid">
        <div class="container">

            <div class="work-area text-center">
                <h3>Products Gallery </h3>
                <div id="slider-1" class="owl-carousel owl-theme">
                    
                   
                    <?php foreach ($best_deal as $key => $rows) { 
                        $mackratt = base64_encode($rows['id'] .SALT_KEY.CKRAT_KEY);
                       ?>
                        <div class="work-item img-fluid">
                            <a href="<?= CUSTOM_BASE_URL . 'product-details/'.$mackratt; ?>"  target="_blank">
                            <img src="<?= CUSTOM_BASE_URL . 'admin/uploads/product_multimage/'.$rows['image_name']; ?>" alt="avvvs"></a>
                            <p><?= $rows['stock_name']; ?></p>
                            </a>
                            </div>
                       <?php }?>  
                    
                      
                       
                    <!--<div class="work-item img-fluid">-->
                    <!--    <img src="<?php echo base_url();?>assets/images/pr-1.png">-->
                    <!--    <p>Red Irons</p>-->
                    <!--</div>-->
                    
                    
                    <!--<div class="work-item img-fluid">-->
                    <!--    <img src="<?php echo base_url();?>assets/images/pr-2.png">-->
                    <!--    <p>Slepan</p>-->
                    <!--</div>-->
                    <!--<div class="work-item img-fluid">-->
                    <!--    <img src="<?php echo base_url();?>assets/images/pr-3.png">-->
                    <!--    <p>Menocare</p>-->
                    <!--</div>-->
                    <!--<div class="work-item img-fluid">-->
                    <!--    <img src="<?php echo base_url();?>assets/images/pr-4.png">-->
                    <!--    <p>Satavari Gulam</p>-->
                    <!--</div>-->
                    <!--<div class="work-item img-fluid">-->
                    <!--    <img src="<?php echo base_url();?>assets/images/pr-5.png">-->
                    <!--    <p>Jeevana</p>-->
                    <!--</div>-->
                    <!--<div class="work-item img-fluid">-->
                    <!--    <img src="<?php echo base_url();?>assets/images/pr-6.png">-->
                    <!--    <p>Hair Greens</p>-->
                    <!--</div>-->
                    
                    
                    
                    
                </div>

                <div class="btns">
                    <div class="customNextBtn d-flex justify-content-center align-items-center"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
                    <div class="customPreviousBtn d-flex justify-content-center align-items-center"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
                </div>

                <a href="<?= CUSTOM_BASE_URL;?>product-list" class="read-mre-fill mt-0">More Products</a>
            </div>
        </div>



    </section>

    

    
    <section class="shop-area">
        <div class="container">
            <div class="shop-inner-homer">
                <img class="img-fluid" src="<?php echo base_url();?>assets/images/tulasi.png">
                <h4>Ayurvaram Clinics-<span>Specialised <br>Ayurveda Healthcare</span></h4>
                <p>The best of both worlds can be achieved if we blend together technology and tradition. To give you potent herbal medicines with 100% efficacy, that is what we have done. We have stringent quality control measures in place so that using technical.</p>

                <!--<a class="read-mre-line" href="#">Our Shop</a>-->
                
                
                    <button class="btn-appoiment" onclick="document.location='<?="consulting"?>'">Book Your Appoinment</button>


            </div>
        </div>
    </section>


    <!--<section class="testimonial">
        <div class="container">
            <div class="testi">
                <h6>Testimonials</h6>
                <div id="slider-3" class="owl-carousel owl-theme">
                    <div class="text-center">
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia.</p>
                        <span>- Rama Krishnan</span>
                    </div>

                    <div class="text-center">
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia.</p>
                        <span>- Gopal Krishna</span>
                    </div>

                    <div class="text-center">
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia.</p>
                        <span>- Sudheesh Kumar</span>
                    </div>

                </div>
            </div>

        </div>
    </section>-->

<!--<div id="show-hidden-menus">Click Me!</div>
<div class="hidden-menus" style="display: none;">
  <ul>
    <li>List item 1</li>
    <li>List item 2</li>
    <li>List item 3</li>
  </ul>
</div>-->

<script type="text/javascript">
  $(document).ready(function () {

    var er = 0;

   $("#subscriber").click(function () {

      var email =  $("#email").val();

      var AtPos = email.indexOf("@");
      var StopPos = email.lastIndexOf(".");

      if (email == "") 
      {
          document.getElementById('email').style.border = '1px dashed red';
          er = 1;
      }
      else if (email.indexOf('@') == '-1' || email.lastIndexOf('.') < 2) {
          document.getElementById("email_id").innerHTML = "Please fill valid email id";
          document.getElementById('email').style.border = '1px dashed red';
          er = 1;
      } else if (!((email.length - StopPos) > 2)) {
          document.getElementById("email_id").innerHTML = "Please fill valid email id";
          document.getElementById('email').style.border = '1px dashed red';
          er = 1;
      }
      else{
          document.getElementById("email_id").innerHTML = "";
          document.getElementById('email').style.border = '';
      

        $.ajax({
              type: 'post',
              url: '<?= CUSTOM_BASE_URL . 'Main/subscribe_create' ?>', //Here you will fetch records 
              data: 'email=' + email , //Pass $id
              success: function (data) {
                  
                if(data==1)
                {

                  $('#sucess').html("<div class='alert alert-success'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Sucessfully Subscribed</div>");

                }
                else{

                  $('#sucess').html("<div class='alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Failed Subscribed</div>");


                }
              }
          });

        }

    });
}); 
</script>





 <?php include("web/assets/include/footernew.php");?>



   <!-- <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>-->
<!--    <script type="text/javascript" src="<?php echo base_url();?>assets/js/vendor.js"></script>-->
<!--    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>

   <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/vendor.JS"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/active.JS"></script>



    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/smoothscrolling.js"></script>
    <!--=== Revolution Slider Js ===-->
    <script src="<?php echo base_url();?>assets/js/revslider/jquery.themepunch.tools.min.js"></script>
    
    <script src="<?php echo base_url();?>assets/js/revslider/jquery.themepunch.revolution.min.js"></script>
   <!-- <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>-->
<script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.actions.min.js"></script>
<script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.carousel.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.kenburn.min.js"></script>
    
    
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.migration.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.navigation.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.parallax.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.slideanims.min.js"></script>
    
    <script src="<?php echo base_url();?>assets/js/revslider/extensions/revolution.extension.video.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/revslider/revslider-active.js"></script>
    
    



