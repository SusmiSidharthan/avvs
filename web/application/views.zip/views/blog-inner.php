<!--<!doctype html>-->
<!--<html class="no-js" lang="en">-->

<!--<head>-->
<!--    <title>AVVVS - Blog</title>-->
<!--    <meta charset="utf-8">-->
<!--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />-->
<!--    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />-->
<!--    <meta name="author" content="">-->
<!--    <meta name="description" content="">-->

<!--    <meta name="keywords" content="">-->

<!--    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.png">-->

<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap" rel="stylesheet">-->
<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Roboto&display=swap" rel="stylesheet">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/avvvs.css">-->

<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/plugins.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/style.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/vendor.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">-->





<!--</head>-->

<!--<body id="blog-menu">-->


  
<?php include("web/assets/include/header-c.php");?> 

    <section class="banner-inner-classic">
        <img class="img-fluid about-banner-left-img" src="<?php echo base_url();?>assets/images/classical-banner-left.png">
        <div class="container">
            <h1>Authentic Kerala<br> Ayurveda Medicines
            </h1>
        </div>
        <img class="img-fluid banner-right-img" src="<?php echo base_url();?>assets/images/banner-right-img.png">
        <img class="img-fluid pot-banner" src="<?php echo base_url();?>assets/images/classic-pot.png">
    </section>

   

    <section class="producs-classic">
        <img class="img-fluid classic-tulasi" src="<?php echo base_url();?>assets/images/tulasi-small.png">
        <img class="img-fluid left-bg" src="<?php echo base_url();?>assets/images/classical-products-bg-left.png">
        <div class="container index-top">

            <!--<h1 class="m-5 text-center">MY BLOGS</h1>
  <hr>-->
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-detail light-bg">
                        <img src="<?php echo base_url();?>assets/images/blog/inner-pic/01.jpg" class="img-fluid blog-detail-pic">
                        <h3>Ancient Medicine, Contemporary Practices and Modern Technology, The Arya Vaidya Vilasini Vaidya Sala
</h3>
                        <h5>Nalin Reddy</h5>
                        <h5><span>21</span> July 2020</h5>
                        <p>Shubhra Krishan, in her book Essential Ayurveda, reaches out to the readers on how to better understand the energy associated with their mind body and soul, and on how Ayurveda can help in achieving better health. She wrote “The great thing about Ayurveda is that its treatments always yield side benefits, not side effects”.
With the sole purpose of serving the ailing society by establishing a patient care facility, providing compassionate Ayurveda healthcare, Arya Vaidya Vilasini Vaidya Sala was established by Kaloor Neelakandan Vaidyar, with the blessings of Sree Narayan Guru.<br>
In the 99 years of making, this medical institution has made a milestone out of every opportunity under the extraordinary guidance of the generations of the Kaloor family. In order to tend to more patients, the institution has expanded into chain of clinics and set up agencies in most of South-India. Kaloor Ramadas Vaidyar has made sure to expand the reach of the institution into socio-cultural and literary circles of Kozhikode. <br>
Dr. Manoj Kaloor, a post graduate in Ayurveda with specialization in Shalakya Tantra, (Shalakya Tantra deals with the etiology, diagnosis, prognosis, prevention and treatment of diseases that are located above the neck region such as the head, ear, nose, eye and throat. It is responsible for all types of problems in and around the head. The name of the branch is so called because of its excessive use of 'Shalaka', which means probe), seasoned clinician, renowned academician was presented with the responsibility of outshining the organization into today’s leading manufacturer of Ayurveda medicine with a wide range of products for various ailments in India and exports to countries; Russia, Austria, Slovenia and Columbia. Catering to the needs of the society, Ayurvaram Ayurveda Speciality clinics offer specialty outpatient health care services through a range of speciality clinics spread across the State, such as Head Ache Clinic, ENT Clinic, Eye Care Clinic, Women Health Clinic, Health and Beauty Clinic, Lifestyle Clinic, Pregnancy and Post Natal Care Clinic and Child Health Clinic. <br>
The institution’s success in developing, manufacturing and dispensing safe, reliable, authentic, effective and affordable Ayurveda products to mankind globally is by adapting to the evolving technology without compromising on the core tradition, a value that has sustained and nurtured the prosperity of the institution throughout a century.
In order to achieve the vision of being a premium multi-faceted Ayurveda global ethical business institution committed to quality and guided by tradition, AVVVS has always evolved with time incorporating the contemporary changes and trends in the industry. The present GMP certified factory with state-of-the-art technology and modern manufacturing equipment are proofs to its scientific approach. The factory located in the suburbs of the city has modern machineries for capsulation, blister packing, ointment manufacturing and filling, cosmetic products manufacturing apart from the traditional mechanised manufacturing units manned by trained and experienced personnel.<br>
The present management of AVVVS continues to serve under the leadership of Dr. Manoj Kaloor and Dr. Reeja Manoj, blending technology and tradition with service as one of its core principles. 
</p>
                    </div>

                </div>
                <div class="col-md-4">

                    <div class="row recent-box flex-container">
                        <div class="col-12">
                            <h4>Recent posts</h4>
                            <hr>
                        </div>

                        <div class="col-4"><a href="blog-inner4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/001.jpg" class="img-fluid"></a>
                        </div>
                        <div class="col-8 recent-box-detail">
                            <a href="blog-inner4">
                            <p>21 July 2020</p>
                            <h6>Ancient Medicine, Contemporary Practices and Modern Technology, The Arya Vaidya Vilasini Vaidya Sala</h6>
                            </a>
                        </div>
                       
                        <div class="col-12 border-line">

                        </div>
<a href="blog-inner3">
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/002.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>10 August 2020</p>
                            <h6>Ayurvedic Answers</h6>
                        </div>
                        </a>
                        <div class="col-12 border-line">

                        </div>
                        
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/003.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>23 August 2020</p>
                            <h6>Stress : managing your headspace to de-stress</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/004.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>2 September 2020</p>
                            <h6>Ayurveda Vs Modern Medicine</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/recent-icon.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>14 September 2020</p>
                            <h6>Dinacharya: the ideal daily routine according to Ayurveda</h6>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </section>








 <?php include("web/assets/include/footernew.php");?>



    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>

    <!-- <script type="text/javascript" src="js/slider/vendor.JS"></script> -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/active.JS"></script>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/smoothscrolling.js"></script>







</body>

</html>