<?php include("header-c.php");?>

<section class="not-fd-ban-a"> 
 
 <div class="container">
  <div class="row justify-content-md-center">
    <div class="col-md-6">
     <div class="not-fd-ban-ab">
      <img src="../../images/not-found.jpg">
      <a href="#">Go Back</a>
     </div>
    </div>
  </div>
 </div> 

</section>







 <?php include("footer.php");?>