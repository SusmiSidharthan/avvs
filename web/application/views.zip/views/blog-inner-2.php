<!--<!doctype html>-->
<!--<html class="no-js" lang="en">-->

<!--<head>-->
<!--    <title>AVVVS - Blog</title>-->
<!--    <meta charset="utf-8">-->
<!--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />-->
<!--    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />-->
<!--    <meta name="author" content="">-->
<!--    <meta name="description" content="">-->

<!--    <meta name="keywords" content="">-->

<!--    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.png">-->

<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap" rel="stylesheet">-->
<!--    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Roboto&display=swap" rel="stylesheet">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/avvvs.css">-->

<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/plugins.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/style.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slider/vendor.css">-->
<!--    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">





<!--</head>-->


<?php include("web/assets/include/header-c.php");?> 

<!--<body id="blog-menu">-->


    <section class="banner-inner-classic">
        <img class="img-fluid about-banner-left-img" src="<?php echo base_url();?>assets/images/classical-banner-left.png">
        <div class="container">
            <h1>Authentic Kerala<br> Ayurveda Medicines
            </h1>
        </div>
        <img class="img-fluid banner-right-img" src="<?php echo base_url();?>assets/images/banner-right-img.png">
        <img class="img-fluid pot-banner" src="<?php echo base_url();?>assets/images/classic-pot.png">
    </section>

   

    <section class="producs-classic">
        <img class="img-fluid classic-tulasi" src="<?php echo base_url();?>assets/images/tulasi-small.png">
        <img class="img-fluid left-bg" src="<?php echo base_url();?>assets/images/classical-products-bg-left.png">
        <div class="container index-top">

            <!--<h1 class="m-5 text-center">MY BLOGS</h1>
  <hr>-->
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-detail light-bg">
                        <img src="<?php echo base_url();?>assets/images/blog/inner-pic/03.jpg" class="img-fluid blog-detail-pic">
                        <h3>Stress : managing your headspace to de-stress
</h3>
                      
                        <h5>Parimala Pratibha Konnur</h5>
                        <h5><span>23</span> August 2020</h5>
                        <p>In today’s world, it is almost impossible to find a person who does not deal with stress in their life. Every person’s definition of stress is unique, the reasons vary and the effects may manifest in completely different ways, however, the one thing that is common to everyone is that stress isn’t doing anyone any favors. The involvement of stress in several diseases is well recognized in Ayurveda as well as modern medicine. Stress is known as sahasa in Ayurveda. Stress can cause numerous health issues such as headaches, indigestion, heart disease, PCOS in females and mental health issues.<br>

According to Ayurveda, stress on the body and mind is the primary reason for all problems in our lives – physical, mental, social, economic and spiritual. Stress plays a role in the onset of just about every disease people face, from the common cold to heart disease. The immune system is gradually weakened, inviting a multitude of pathogens into the body which in turn breaks down the internal defense mechanism. The greatest factor in a person’s sensitivity to stress is a substance found within all cellular tissues and the mind, called ojas. Ojas is the essence of the immune system and provides the mind with both stability and contentment. Ojas is produced by the body as the body digests nutritious food items. Hence, a nourishing diet combined with excellent digestion is a major key to building ojas. Ayurveda emphasizes keenly on proper digestion. This includes selecting the proper foods for a person’s constitution, as well as mindful consumption. Long term digestion and elimination issues deplete the body of ojas. To maintain a healthy level of ojas, a lifestyle that avoids overindulgence includes significant rest, and reinforcing self-love, is a must.<br>

Another important aspect is that the mind and body are intertwined entities. One cannot be healthy if the other is not. All physical health problems have their source in the mind and all mental stress and psychological fears are inadvertently reflected in our physical body. The Ayurvedic approach to stress management is focused on relieving the stress from the nervous system while improving the relaxation of the entire body. Other than a balanced diet, meditation, pranayama and yoga act as therapeutic methods to approach peace holistically. They help in resetting the rhythms and re-establishing equilibrium in the body, which is a prime requirement in stress management.<br>

Some simple methods by which stress can be alleviated:Some simple methods by which stress can be alleviated:<br>

Take a few deep breaths during the day
Discuss your issues; sharing takes away a portion of the burden
Organize some part of your life, anything from a messy table to a cluttered inbox can help in making you feel in control
Bring some herbs into your life (teas, essential oils etc); Rasayana therapy is calming
Eat fresh meals and drink enough water<br>

Finally, even though it might seem redundant to read “change your lifestyle to see changes in your health”, it is a fact. By reducing stress, we can get closer to achieving optimum health.





</p>
                    </div>

                </div>
                <div class="col-md-4">

                    <div class="row recent-box flex-container">
                        <div class="col-12">
                            <h4>Recent posts</h4>
                            <hr>
                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/001.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>21 July 2020</p>
                            <h6>Ancient Medicine, Contemporary Practices and Modern Technology, The Arya Vaidya Vilasini Vaidya Sala</h6>

                        </div>
                        <div class="col-12 border-line">

                        </div>

                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/002.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>10 August 2020</p>
                            <h6>Ayurvedic Answers</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/003.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>23 August 2020</p>
                            <h6>Stress : managing your headspace to de-stress</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/inner-pic/004.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>2 September 2020</p>
                            <h6>Ayurveda Vs Modern Medicine</h6>
                        </div>
                        <div class="col-12 border-line">

                        </div>
                        <div class="col-4">
                            <img src="<?php echo base_url();?>assets/images/blog/recent-icon.jpg" class="img-fluid">
                        </div>
                        <div class="col-8 recent-box-detail">
                            <p>14 September 2020</p>
                            <h6>Dinacharya: the ideal daily routine according to Ayurveda</h6>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </section>








 <?php include("web/assets/include/footernew.php");?>

    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog-style.css">

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>

    <!-- <script type="text/javascript" src="js/slider/vendor.JS"></script> -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/active.JS"></script>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/slider/smoothscrolling.js"></script>





<!--
    <script>
        $(document).ready(function() {
            var scrollTop = 0;
            $(window).scroll(function() {
                scrollTop = $(window).scrollTop();
                $('.counter').html(scrollTop);

                if (scrollTop >= 100) {
                    $('#global-nav').addClass('scrolled-nav');
                } else if (scrollTop < 100) {
                    $('#global-nav').removeClass('scrolled-nav');
                }

            });

        });
    </script>
    <script>
        $(".menu-icon").click(function() {
            $(".menu").slideToggle("slow", function() {
                // Animation complete.
            });
        });
    </script>

    <script>
        $('.menu-icon').click(function() {
            $(this).toggleClass('open');
        });
    </script>-->

</body>

</html>